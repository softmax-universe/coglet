import json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
trace=json.loads((root/'prepared-model/trace.json').read_bytes())
p=subprocess.run([str(root/'repo/target/static-proof/x86_64-unknown-linux-gnu/debug/coglet-unforged-proof'),'record',str(root/'prepared-model/trace.json')],capture_output=True,check=True)
actual=json.loads(p.stdout)
print('trace keys',sorted(trace),'actual keys',sorted(actual))
for k in trace.keys()|actual.keys():
    if trace.get(k)!=actual.get(k):
        print(k, 'present',k in trace,k in actual)
        if k=='records':
            for i,(a,b) in enumerate(zip(trace[k],actual[k])):
                print(i,[(key,str(a.get(key))[:100],str(b.get(key))[:100]) for key in a.keys()|b.keys() if a.get(key)!=b.get(key)])
        else:print(str(trace.get(k))[:100],str(actual.get(k))[:100])
