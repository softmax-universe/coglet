import ast,hashlib,json,re,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent
repo=root/'repo';batch=root/'hosted-resolver-reviewed'
files=[]
for p in sorted((repo/'tests/unforged_proof').glob('test_*.py')):
    names=[n.name for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')]
    files.append(dict(file=str(p.relative_to(repo)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),count=len(names),tests=names))
old=json.loads((repo/'tests/unforged_proof/existing-test-inventory.json').read_bytes())
missing=[]
for entry in old['files']:
    p=root/entry['file']
    if not p.exists():missing.append(entry['file'])
    else:
        text=p.read_text()
        for name in entry['tests']:
            if re.search(r'\b'+re.escape(name)+r'\b',text) is None:missing.append(entry['file']+':'+name)
if missing:raise RuntimeError(missing)
summary=dict(current_fast_source_files=files,current_fast_definitions=sum(f['count'] for f in files),baseline_files=len(old['files']),baseline_definitions=sum(f['count'] for f in old['files']),baseline_missing=missing)
(batch/'inventory.json').write_text(json.dumps(summary,indent=2)+'\n')
archive=repo/'tests/unforged_proof/evidence/hosted-resolver-interim.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tf:
    for p in sorted(batch.iterdir()):
        if p.name not in ('os','prefix.json'):tf.add(p,arcname='hosted-resolver-reviewed/'+p.name)
    for p in [root/'verify_resolver_negatives.py',root/'compare_resolver_oracle.py',Path(__file__).resolve()]:tf.add(p,arcname=p.name)
print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),baseline_files=summary['baseline_files'],baseline_definitions=summary['baseline_definitions'],baseline_missing=missing,fast_definitions=summary['current_fast_definitions'])))
