"""Local mutations of retained ACTUAL bytes, never hosted upgrades/executions."""
import copy,json,sys,tempfile,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'repo/tests/unforged_proof'))
from verify_resolver_probe import verify
batch=ROOT/'hosted-resolver-reviewed'
config=json.loads((batch/'command.json').read_bytes())
kwargs=dict(source=config['source'],driver=config['driver_sha256'],bridge=config['bridge_sha256'],image=config['pins']['image'],endpoint=config['pins']['endpoint'],resolver=config['pins']['resolver_a'])
checked=verify(batch,**kwargs)
rows=[json.loads(line) for line in (batch/'bridge.jsonl').read_text().splitlines()]
mutations=[]
for name,change in [('missing_receipt',lambda r:r[1].update(raw_receipt='')),('ambiguous_receipt',lambda r:r[1].update(raw_receipt=r[1]['raw_receipt']+'\n'+r[1]['raw_receipt'])),('wrong_resolver',lambda r:r[3].update(resolver=config['pins']['resolver_a'])),('missing_run',lambda r:r.pop()),('duplicate_run',lambda r:r.append(r[-1])),('first_b_hit',lambda r:r[3].update(memo_hit=True)),('warm_a_miss',lambda r:r[2].update(memo_hit=False)),('warm_b_miss',lambda r:r[4].update(memo_hit=False)),('return_a_miss',lambda r:r[5].update(memo_hit=False)),('wrong_tree',lambda r:r[3].update(tree='0'*64))]:
    with tempfile.TemporaryDirectory(prefix='resolver-local-negative-',dir=ROOT) as td:
        out=Path(td)
        for p in batch.iterdir():
            if p.is_file():shutil.copyfile(p,out/p.name)
        (out/'objects').symlink_to(batch/'objects',target_is_directory=True)
        modified=copy.deepcopy(rows);change(modified)
        (out/'bridge.jsonl').write_text('\n'.join(json.dumps(r) for r in modified)+'\n')
        try:verify(out,**kwargs)
        except ValueError as e:mutations.append(dict(name=name,refused=str(e),kind='local-retained-byte-mutation'))
        else:raise RuntimeError(name+' incorrectly accepted')
for key,value in [('image','native@sha256:'+'0'*64),('resolver','0'*64),('source','0'*40),('driver','0'*64),('bridge','0'*64)]:
    wrong=dict(kwargs);wrong[key]=value
    try:verify(batch,**wrong)
    except ValueError as e:mutations.append(dict(name='changed_expected_'+key,refused=str(e),kind='local-expected-pin-mutation'))
    else:raise RuntimeError(key+' incorrectly accepted')
summary=dict(actual_observations=len(checked['observations']),unique_commits=len({r['commit'] for r in checked['observations']}),actual_executed=sum(r['receipt']['executed'] for r in checked['observations']),actual_remote_hits=sum(r['receipt']['cache']=='caos' for r in checked['observations']),local_negatives=mutations)
(batch/'local-negatives.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
