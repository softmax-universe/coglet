"""Local synthetic oracle acquisition; intentionally before selecting export."""
import gzip, hashlib, json, os, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'repo/tests/unforged_proof'))
from prefix_inputs import step_payload
repo=ROOT/'repo'
driver=repo/'target/static-proof/x86_64-unknown-linux-gnu/debug/coglet-unforged-proof'
clean={k:v for k,v in os.environ.items() if k not in ('CAOS_IROH_TICKET','UNFORGED_CAOS_URL')}
out=ROOT/'canary-oracles';out.mkdir(exist_ok=False)
commands=[]
def native(*args):
    argv=[str(driver),*map(str,args)]
    result=subprocess.run(argv,capture_output=True,env=clean,check=True,timeout=120)
    commands.append(argv)
    return result.stdout
model=native('record-model',repo)
(out/'model.json').write_bytes(model)
source=gzip.decompress((repo/'tools/visualizer/native/fixtures/m2-gridbot-trace.json.gz').read_bytes())
(out/'gridbot-source.json').write_bytes(source)
gridbot=native('record',out/'gridbot-source.json');(out/'gridbot.json').write_bytes(gridbot)
for name,raw,indices in [('model',model,[0,1]),('gridbot',gridbot,[2])]:
    trace=json.loads(raw)
    for i in indices:
        prefix=out/f'{name}-{i}-prefix.json';prefix.write_text(json.dumps(step_payload(trace,i)['prefix']))
        snapshot=native('snapshot',prefix);(out/f'{name}-{i}-snapshot.json').write_bytes(snapshot)
        print(json.dumps(dict(oracle=name,step=i,coglet=trace['coglet'],tree=trace['records'][i]['output_hash'])))
(out/'commands.json').write_text(json.dumps(dict(commands=commands,source_head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD']).decode().strip(),driver_sha256=hashlib.sha256(driver.read_bytes()).hexdigest()),indent=2))
