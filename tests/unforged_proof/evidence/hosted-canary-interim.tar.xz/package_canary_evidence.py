"""Package exact reviewed loopback evidence; no staging/authority directories."""
import hashlib,json,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent
jobs=[root/'hosted-canary-model-0',root/'hosted-canary-model-1',root/'hosted-canary-gridbot-2']
results=[json.loads((p/'independent-verification.json').read_bytes()) for p in jobs]
if len(results)!=3 or len({r['request'] for r in results})!=3:raise ValueError('complete unique jobs missing')
summary=dict(count=len(results),unique_requests=len({r['request'] for r in results}),results=results,qualification='loopback only; NOT universal no-effects or stage2 PASS')
(root/'canary-summary.json').write_text(json.dumps(summary,indent=2))
for name in ('model','gridbot'):
    trace=json.loads((root/'canary-oracles'/f'{name}.json').read_bytes())
    print(name,'records',len(trace['records']),'first record keys',list(trace['records'][0]))
archive=root/'repo/tests/unforged_proof/evidence/hosted-canary-interim.tar.xz'
with tarfile.open(archive,'w:xz',preset=9) as tar:
    for path in jobs+[root/'canary-oracles',root/'canary-summary.json',root/'acquire_canary_oracles.py',root/'package_canary_evidence.py',root/'native-regressions-canary.txt',root/'native-regressions-canary-tail.txt',root/'native-regressions-canary-tail.xml',root/'native-regression-aggregate.json',root/'aggregate_native_regressions.py',root/'prepare_native_regression_guest.py']:
        tar.add(path,arcname=path.name)
raw=archive.read_bytes()
print(json.dumps(dict(archive=str(archive),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),count=len(results))))
