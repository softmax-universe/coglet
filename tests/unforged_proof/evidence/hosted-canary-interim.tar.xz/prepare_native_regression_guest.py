import json
from pathlib import Path
root=Path(__file__).resolve().parent
trace=json.loads((root/'canary-oracles/gridbot.json').read_bytes())
(root/'native-regression-pilot.wasm').write_bytes(bytes.fromhex(trace['initial_files']['/code/bin/step.wasm']))
print('native regression guest taken from genuine existing Gridbot fixture')
