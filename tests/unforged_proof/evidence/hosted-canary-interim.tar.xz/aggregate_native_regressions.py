import json,re,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
root=Path(__file__).resolve().parent
files=['test_native.py','test_evaluation.py','test_gate_artifacts.py','test_gate_adversarial.py','test_gate_service.py']
command=[str(root/'repo/sim/.venv/bin/python'),'-m','pytest',*[str(root/'repo/sim/tests'/p) for p in files],'--collect-only','-q']
collected=subprocess.run(command,capture_output=True,text=True,check=True)
# Collection prints file-relative IDs; normalize only repository path prefix.
expected=set()
for line in collected.stdout.splitlines():
    if '::' in line and line.startswith('tests/'):
        expected.add('repo/sim/'+line)
if not expected:raise ValueError(collected.stdout)
passed=set(); pending=None
for line in (root/'native-regressions-canary.txt').read_text().splitlines():
    if line.startswith('repo/sim/tests/'):
        pending=line.split(' ',1)[0]
    if pending and (' PASSED' in line or line=='PASSED'):
        passed.add(pending);pending=None
first=set(passed)
xml=ET.parse(root/'native-regressions-canary-tail.xml')
for case in xml.iter('testcase'):
    if any(case.find(k) is not None for k in ('failure','error','skipped')):raise ValueError('tail not green')
    module=case.attrib['classname'].split('.')[-1]
    passed.add(f'repo/sim/tests/{module}.py::{case.attrib["name"]}')
missing=expected-passed;extra=passed-expected
if missing or extra:raise ValueError(dict(missing=sorted(missing),extra=sorted(extra)))
result=dict(expected_count=len(expected),first_partial_passed=len(first),tail_passed=sum(1 for _ in xml.iter('testcase')),unique_passed=len(passed),missing=[],tests=sorted(passed),first_status='foreground tool timeout420s; partial only; exact remaining selection completed separately',tail_status='exit0',qualification='selected retained native/gate regressions, not stage2')
(root/'native-regression-aggregate.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='tests'}))
