"""Run retained native gate regression cases on actual built tools, no model calls."""
import json
import os
from pathlib import Path
import subprocess
workspace=Path(__file__).resolve().parent
repo=workspace/'repo'
archive=json.loads((workspace/'factory-native-archive-fixed/archive.json').read_bytes())
wasm=workspace/'factory-regression-pilot.wasm'
wasm.write_bytes(bytes.fromhex(archive['initial_files']['/code/bin/step.wasm']))
env={k:v for k,v in os.environ.items() if k not in ('CAOS_IROH_TICKET','UNFORGED_CAOS_URL')}
base=repo/'target/static-proof/x86_64-unknown-linux-gnu/debug'
env.update(COGLET_SANDBOX_DAEMON=str(base/'cogletd'),COGLET_SANDBOX_PROOF=str(base/'coglet-sandbox-proof'),COGLET_SANDBOX_WASM=str(wasm))
result=subprocess.run(['uv','run','--project',str(repo/'sim'),'--locked','pytest',str(repo/'sim/tests/test_gate_artifacts.py'),str(repo/'sim/tests/test_evaluation.py'),'-q'],env=env,capture_output=True,timeout=180)
(workspace/'factory-native-regressions.txt').write_bytes(result.stdout+result.stderr)
print((result.stdout+result.stderr).decode())
raise SystemExit(result.returncode)
