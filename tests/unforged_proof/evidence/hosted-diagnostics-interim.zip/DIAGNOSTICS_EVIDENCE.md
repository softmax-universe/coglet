# Stage2 diagnostic transport increment — NOT stage2 PASS

Reviewed source: Coglet 0c143e21fc5138c879ceb8207c9d95693291eaef.
Consumed Unforged: f9c627bcc09346b2923583037a10ac9a2fa8ea12, unchanged.
Inspected CAOS source:604b6024166e5eb4ffa41e3555c2f5f0bd9d06b6, unchanged; deployed /version=unknown, not a deployed-source pin.
Bridge binary for reviewed execution/readback: SHA256 b59f8dd689027b51a922bfa51ca76c65a2778c6f66ff533f52496196eeb0e776.

Latest source-containing execution and separate readback are hosted-diagnostics-reviewed/ and hosted-diagnostics-reviewed-readback/. Actual request7147019a668131c2aa813a8731521fbeb6d29b2b; sidecar5b4c99dea1026317833f6e63b2f1dc08a4d011e3. Actual receipt: cache_hit=false, requested-nocache plus X-Caos-Cache=miss inference, exact independently pinned worker image. Worker saw net:[4026532663], effective policy env fields unset. These are observations only, NOT isolation, no-live-effects, Coglet execution or factory qualification.

Earlier hosted-diagnostics/ ran sourcee9c6f97486082f90ab824d275133ecf73af008ae: executed but statusnull -> exit1. Later hosted-diagnostics-readback/ source was uncommitted refinement ofe9c6f97; /versionunknown and statusnull. hosted-diagnostics-bound/ source was uncommitted native-binding fix, binaryf35baf02..., raw bytes not yet printed by that binary. hosted-diagnostics-bound-readback/ matches0c143e2 binary and fetched raw bytes independently. Never relabel these as exact-head executions; reviewed/ pair supersedes only success evidence, not historical failure retention.

The initial null arose from native binding changing the ArgTree by adding existing required-native-worker-image. Supplying the expected digest under this arg is safe only because server overwrites it with its authenticated discovered worker; pin check plus exact status/request/salt still mandatory. Ordinary completed status can returnnull; completed ?all=1 is required. Missing/ambiguous sidecar remains refusal.

Reproduction from repo with Unforged sibling:

cargo +1.100.0 build --locked --offline --manifest-path tests/unforged_proof/bridge/Cargo.toml --target-dir ../unforged/target -j2
python3 -m unittest discover -s tests/unforged_proof
python3 -O -m unittest discover -s tests/unforged_proof
python3 tests/unforged_proof/native_bridge_checks.py --bridge ../unforged/target/debug/coglet-hosted-bridge

Run diagnostics_probe.py under token-broker exec --scope caos.prod.connect; exact non-secret commands and per-command binary hashes are in each command.json. Use NEW output dirs. The wrapper generates a fresh consumed salt. Read-only follow-up uses --request with the returned request identity. Broker tickets exist only in process environments and are redacted before capture.

Independent local raw verification (no hosted call):
python3 tests/unforged_proof/verify_diagnostic_probe.py --probe ../hosted-diagnostics-reviewed --readback ../hosted-diagnostics-reviewed-readback --expected-image native@sha256:2e92d104eed5ad02c0daa765c4b17aa35f6be942e39248ef53fdd4987b429ff5

Executed35fast tests normal/-O,6built-bridge CLI negatives PASS;4new sidecar unit cases were RED missing module thenGREEN;3new CLI negatives were RED on old binaries thenGREEN. Actual initial hosted null refusal was RED before native-binding fix then real hosted sidecar retrievalGREEN. Existing6native runtime checks retained, not rebuilt/rerun on this host. Original95files453definition inventory unchanged. Independent separate review sa-0-46a7dc87 APPROVES0c143e2 increment only; not final stage2 review. Latest reviewed-source rerun resolves its source-containing-evidence caveat.

Still pending: actual complete pre-serialization private grant and per-write/send recheck, STANDARD full recorded Coglet wrapper with genuine worker canaries/effect observations, GateService factory integration, actual image/resolver invalidation controls,7named hosted qualification tests, final independent exact-head review/requiredCI/native queue mainmerge/containing-main proof. No PR, no new cards, no server changes or capacity, no paid service. Do not file a missing-sidecar prerequisite: actual readback works.
