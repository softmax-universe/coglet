import sys,json,copy,re,subprocess
from pathlib import Path
ROOT=Path('/home/ubuntu/.hermes/kanban/workspaces/t_01a21c4b5645783f')
sys.path.insert(0,str(ROOT/'repo/tests/unforged_proof'))
import verify_image_probe as v
batch=ROOT/'hosted-image-final'
rows=[json.loads(s) for s in (batch/'bridge.jsonl').read_text().splitlines()]
pins=dict(source='165a9a1ad1128c407f78ba5703955ffb3e0195a2',upstream='c8aeece23b674824ed48f3ea39999a11a92f7173',driver='8113231a72ac1c0ecb94d022c34278ba7446950d757ed829469d2ac019ef9265',bridge='9caf04ca9d6c46e644cfc17f40dad9669fc799ef60979b8a685226942659925c',endpoint='e05401185f40e92e694c635fa75ba4a8cdef5bfcb0f7759f0713decfd6c3d6ce',image_a='localhost:5000/caos@sha256:842b81ee7ab08908ab2cd09ad01c3727a5333c832c2fd76a2974339fc4bf31ad',image_b='localhost:5000/caos@sha256:de985d089552ab9de870c54e6e3e9d028300b517bf7ee389fe1079808b4a4421')
class Text:
 def __init__(self,rs):self.rs=rs
 def read_text(self):return '\n'.join(json.dumps(r) for r in self.rs)
class Batch:
 def __init__(self,rs):self.rs=rs
 def __truediv__(self,name):return Text(self.rs) if name=='bridge.jsonl' else batch/name
results=[]
def check(label,rs):
 try:
  result=v.verify(Batch(rs),**pins)
  status={'label':label,'accepted':True,'summary':result['summary']}
 except Exception as e:status={'label':label,'accepted':False,'error':str(e),'type':type(e).__name__}
 results.append(status);print(json.dumps(status),flush=True)
def fresh():return [dict(r) for r in rows]
check('healthy',rows)
obs=next(r for r in rows if r.get('phase')=='image-observation')
starts=[i for i,r in enumerate(rows) if r.get('phase')=='image-start']
objects,entries,blob,*_=v.graph(rows[starts[0]:starts[1]])
source=subprocess.check_output(['git','show',pins['source']+':tests/unforged_proof/bridge/src/image_controls.rs'],cwd=ROOT/'repo').decode()
for name,constant in [('worker1','WORKER'),('launcher','LAUNCHER')]:
 mode,oid=entries(obs['request'])[name]
 expected=re.search(r'pub const '+constant+r':&str = r#"(.*?)"#;',source,re.S).group(1).encode()
 print(json.dumps({'actual_source_match':name,'mode':mode,'match':blob(oid)==expected}),flush=True)
rs=fresh();next(r for r in rs if r.get('phase')=='request-object')['hex']='00';check('corrupt raw request hash',rs)
rs=fresh();next(r for r in rs if r.get('phase')=='abi-object')['hex']='00';check('corrupt raw output hash',rs)
rs=fresh();r=next(r for r in rs if r.get('phase')=='http' and r['path'].startswith('/status/'));data=json.loads(bytes.fromhex(r['response_hex']));data['arg_tree']='0'*40;r['response_hex']=json.dumps(data).encode().hex();check('wrong status binding',rs)
rs=fresh();r=next(r for r in rs if r.get('phase')=='http' and r['path'].startswith('/run?'));r['path']+='&nocache=1';check('wrong run nocache',rs)
# Coordinated valid graph rewrite, retaining all outputs/oracle/driver/image pins.
# This is deliberately a consistency corruption, not an alleged live execution.
for field in ['worker1','launcher']:
 rs=fresh();mapping={};replacements={}
 old=entries(obs['request'])[field][1];raw=b'exit 125\n';new=v.object_id('blob',raw);mapping[old]=new;replacements[old]=('blob',raw)
 for observation in [r for r in rows if r.get('phase')=='image-observation']:
  req=observation['request'];top=entries(req) if req in objects else None
  if top is None:
   n=next(i for i,r in enumerate(rows) if r.get('phase')=='image-observation' and r['request']==req)
   start=max(i for i in starts if i<n);end=next((i for i in starts if i>n),len(rows))
   _,ent,_,_,_,_=v.graph(rows[start:end]);top=ent(req)
  def tree_bytes(base=True):return b''.join(mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(mapping.get(oid,oid)) for name,(mode,oid) in top.items() if base or name!='base')
  reqraw=tree_bytes();mapping[req]=v.object_id('tree',reqraw);replacements[req]=('tree',reqraw)
  arg=v.object_id('tree',tree_bytes(False));mapping[observation['args']]=arg
  mapping[observation['bundle']]=v.object_id('tree',b'40000 args\0'+bytes.fromhex(arg))
 def replace_ascii(text):
  for old,new in mapping.items():text=text.replace(old,new)
  return text
 for r in rs:
  if r.get('phase')=='request-object':
   if r['oid'] in replacements:
    kind,raw=replacements[r['oid']];r.update(oid=mapping[r['oid']],kind=kind,hex=raw.hex())
  else:
   for key,val in list(r.items()):
    if isinstance(val,str):
     if key in ('body_hex','response_hex'):
      r[key]=replace_ascii(bytes.fromhex(val).decode()).encode().hex()
     else:r[key]=replace_ascii(val)
 check('coherent '+field+' replaced with exit125',rs)
Path(__file__).with_suffix('.results.json').write_text(json.dumps(results,indent=2))
