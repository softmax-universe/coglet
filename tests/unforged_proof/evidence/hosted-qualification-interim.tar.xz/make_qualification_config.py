from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).resolve().parent/'repo'
paths={'driver':root/'target/static-proof/x86_64-unknown-linux-gnu/debug/coglet-unforged-proof','bridge':root.parent/'unforged/target/debug/coglet-hosted-bridge','daemon':root/'target/debug/cogletd','proof':root/'target/debug/coglet-sandbox-proof'}
c={k:str(p) for k,p in paths.items()}
c.update({k+'_sha256':hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()})
c.update(source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),endpoint='e05401185f40e92e694c635fa75ba4a8cdef5bfcb0f7759f0713decfd6c3d6ce',image='native@sha256:2e92d104eed5ad02c0daa765c4b17aa35f6be942e39248ef53fdd4987b429ff5')
(root.parent/'qualification-config.json').write_text(json.dumps(c,indent=2)+'\n')
print(json.dumps(c,indent=2))
