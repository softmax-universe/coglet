# Live qualification composition — NOT stage2 PASS

## Reviewed implementation and inventory

New explicit `qualification.py` exposes all seven named `hosted_*` entrypoints.
They are not unittest-discovered, accept a closed independently pinned operator
configuration, require clean exact source and fresh exclusive output, and never
accept historical result directories as live proof. The aggregate always records
`stage2_pass=false` until the remaining original gates are actually implemented
and verified; no boolean or command callback can waive image/no-effects gaps.
Missing configuration returns nonzero before output. No new dependency, runtime
semantics, scheduler, store, authority primitive or deployed worker was introduced.

Plan initially CHANGES sa-0-a9897e37, corrected bounded plan APPROVE
sa-0-e6ba35d5. Exact executable head
`2347c0b0badaa96040c8a56aaf8fb6ec0fbe10ef` independently APPROVED
sa-0-4899598b. Reviewer independently ran116fast normal/-O, no skips, CLI help
and diff check. This is increment review, NOT final stage2 approval.

Nine LOCAL orchestration tests first RED missing qualification module, then GREEN;
107existing cases retained,116normal/-O PASS. Programmatic named source inventory
retained all95baseline files/453definitions. Original native/bridge suites were
not rerun in this composition increment. No historical test waiver.

## Real execution at reviewed source

The actual full seven-entrypoint command was run, not an archive-only test.
Output `hosted-qualification-reviewed` retained all commands, statuses, diagnostics,
original native oracles, exact source/tool pins, grant scopes and raw authenticated
STANDARD transcripts/full output graphs. Model2steps +Gridbot replay9+fork9 all
executed with fresh salts, observed misses/exact image, per-step full tree equality
and mandatory namespace/loopback controls. Original output graphs and oracle
telemetry were never projected or rewritten.

Honest initial configuration failure: operator accidentally selected the visualizer
binary as factory `proof`, instead of `sim/native`'s coglet-sandbox-proof. Native
factory acquisition refused with usage error before hosted factory execution/signing.
The seven-case run EXIT1 records replay/fork/missing-receipt/private-grant PASS;
factory/image/no-effects FAIL. Original failure/config/diagnostics are preserved.
No successful model/replay/fork batch was rerun.

Corrected only operator configuration to the actual existing sandbox proof binary,
rebuilt it from sim/native, and invoked ONLY
`--case hosted_factory_gate_requires_fresh_execution` with a fresh output
`hosted-qualification-factory-corrected`. EXIT0: behavioral PASS9steps and honest
behavioral rejection3steps; every hosted tree matches its genuine new native suite
archive. Both raw signed artifacts retained, second admission/production refused.
Artifacts `f5f6824f4e136edf526d4100d1adc2b2d8bc637e5e009d168d283fc663e07d6e`
and `f2dcdfbf054ac48c1aec47023dc517e15e28f09bfc1de9a7d123fdefd185b18e`.
This is two runs with correction, not an uninterrupted five-of-seven suite PASS.

Independent `verify_qualification_all.py` rereads raw status/sidecars and rehashes
whole returned object graphs against all actual native oracles, checks factory
challenge/attempt salts/artifact content IDs and requires canaries even on factory
steps: **32executions/32unique requests =2model+9replay+9fork+9factory-pass+3reject**.
Every sidecar reports `1-1-0:refused,refused,loopback-up:1-1-0`, distinct inner netns,
no inherited CAOS URL/fd3. These are synthetic enforcement observations, not a
universal no-effects/provider-attempt certificate. Offline readback is retained
trusted-client evidence, not another fresh server query.

Actual denied source export produces native_started=false/bridge_started=false/
private_staging_writes=0 and no output. A real model-request prefix with its reply
removed refuses with the exact missing-reply ValueError before native/bridge work.
Commands/exit/stdout/stderr persist even though denied probes create no directory.
Missing/ambiguous/changed-image receipt mutants refuse LOCALLY on copies of the
new actual transcript; no fake additional executions or worker upgrade is claimed.

## Exact pins and reproduction

Unforged unchanged `f9c627bcc09346b2923583037a10ac9a2fa8ea12`.
Driver rebuilt static `2528aa44145a5f84b466db51b4a3b51e3f5e5a8ecbc8b66b4496a471d75fe4d4`;
bridge rebuilt `2c37fb55b8b858d8b2b6b175b7e7a6bece319b157ca51ddbbe17210e4fa3c08f`;
native daemon `f5413dbae30ef343024df2eddf438d44ba1330321e4a120ae1417d370f77d602`;
correct native proof `9cfc99a8df85deb6492ccc179040389f3d666f09cffd7a0df6bb6b14489d637d`.
Image `native@sha256:2e92d104eed5ad02c0daa765c4b17aa35f6be942e39248ef53fdd4987b429ff5`;
endpoint `e05401185f40e92e694c635fa75ba4a8cdef5bfcb0f7759f0713decfd6c3d6ce`.
Full argv/configs/snapshots/source traces/native fork request reside in the archive.
No keys, credential tickets or authority stores retained; only synthetic data.

```
# From workspace beside repo/ and unforged/. Build pinned tools as prior evidence.
# Existing sim/native produces coglet-sandbox-proof, NOT visualizer-native.
python3 make_qualification_config.py
# Explicit config includes independent source and every binary digest.
token-broker exec --scope caos.prod.connect --reason 'Reviewed synthetic qualification' -- uv run --project repo/sim --locked python repo/tests/unforged_proof/qualification.py --config qualification-config.json --output NEW-EXCLUSIVE-DIRECTORY
# Expected nonzero until actual image transition and no-effects closure complete.
uv run --project repo/sim --locked python verify_qualification_all.py
```

## Remaining no-effects/source audit and image wall

Independent read-only source audit sa-0-dcdb40e7 confirms no reachable provider or
adapter dispatcher on actual bare-driver Runtime.step -> NativeEngine -> StepHost
path: StepHost only records emit/timer/llm/log, WASI uses in-memory snapshots,
recorded replies enter through boundary changes. However default device features
and coglet-cli dependencies compile networking/service code into the driver.
Do not relabel that as structurally unavailable live dispatch. Suggested next
increment: isolate CLI preparation from hosted bare driver and prune default-device/
CLI networking dependency closure, lock it with cargo-tree tests, then review exact
head and rerun changed binary with all canaries. The named no-effects entrypoint
currently FAILS honestly after retaining exact-head observations. No frozen
contract or runtime effect-path rewrite is needed or authorized.

Actual retained-client native image A/B transition is STILL unqualified. Existing
native worker exposes no supported client rotation; no deployment/capacity was
performed or authorized. Changed expected-pin refusal is not a worker change.
Keep that named test failing rather than fabricate a transition. Scope-owner
reconciliation is needed if no existing supported alternate can exercise it.

Original separate retained-client warm/resolver evidence remains separate; this
STANDARD batch does not replace it. Final independent exact-head review, required
CI, native queue/main merge, containing-main hosted proof and durable FINAL evidence
handoff remain. This committed interim attachment is NOT final stage2 PASS.
