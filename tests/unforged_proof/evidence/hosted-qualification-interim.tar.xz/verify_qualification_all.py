"""Offline independent readback of this run's actual qualification output."""
import json,pathlib,sys,subprocess
root=pathlib.Path(__file__).resolve().parent
repo=root/'repo';sys.path.insert(0,str(repo/'tests/unforged_proof'))
from verify_loopback_probe import verify
from guarded_transport import strict_json,digest
from diagnostic_receipts import verify_loopback_sidecar
from verify_factory_probe import verify as factory_verify
from coglet_gate.hosted import validate_steps
job=root/'hosted-qualification-reviewed';config=strict_json((job/'config.json').read_bytes())
qualification=strict_json((job/'qualification.json').read_bytes())
if set(qualification['cases'])!=set(__import__('qualification').NAMES):raise ValueError('missing named gate')
checked=[]
for label,path in [('model',job/'model.json'),('replay',job/'oracles/replay-trace.json'),('fork',job/'oracles/fork-trace.json')]:
    trace=strict_json(path.read_bytes())
    for index,_ in enumerate(trace['records']):
        r=verify(job/f'{label}-{index}',path,index,image=config['image'],source=config['source'],driver_hash=config['driver_sha256'],bridge_hash=config['bridge_sha256'])
        checked.append(dict(entry=label,**r))
for label in ('factory-pass','factory-reject'):
    p=root/'hosted-qualification-factory-corrected'/label;request=strict_json((p/'request.json').read_bytes());evaluation=strict_json((p/'evaluation.json').read_bytes())
    artifact=(p/'artifact.json').read_bytes();result=strict_json((p/'result.json').read_bytes())
    if digest(artifact)!=result['artifact'] or strict_json(artifact)['payload']!=evaluation:raise ValueError('raw artifact differs')
    hosted=evaluation['report']['hosted'];oracles=list((p/'steps').glob('*/native-oracle.json'))
    if len(oracles)!=1:raise ValueError('oracle missing/ambiguous')
    archive=strict_json(oracles[0].read_bytes());validate_steps(hosted['steps'],archive,request,hosted['identity'],hosted['attempt'])
    command=strict_json((p/'command.json').read_bytes())
    if command['source_head']!=config['source']:raise ValueError('factory source differs')
    factory_config=strict_json((root/'hosted-qualification-factory-corrected/config.json').read_bytes())
    for n in ('driver','bridge','daemon','proof'):
        if command[n+'_sha256']!=factory_config[n+'_sha256']:raise ValueError('factory tool differs')
    for step,record in zip(hosted['steps'],archive['records'],strict=True):
        rows=[strict_json(line) for line in (p/'steps'/step['salt']/'bridge.jsonl').read_bytes().splitlines()]
        r=factory_verify(rows,step,request,hosted['attempt'],config['image'],record['output_hash'])
        sidecars=[x for x in rows if x.get('phase')=='sidecar-readback']
        if len(sidecars)!=1:raise ValueError('sidecar ambiguous')
        observations=verify_loopback_sidecar(sidecars[0]['raw_payload'].encode(),sidecars[0]['oid'],request=r['request'],salt=step['salt'])
        checked.append(dict(entry=label,**r,canary=observations))
if len({r['request'] for r in checked})!=len(checked):raise ValueError('duplicate request')
summary=dict(source=config['source'],count=len(checked),unique_requests=len({r['request'] for r in checked}),
    per_path={label:sum(r['entry']==label for r in checked) for label in ('model','replay','fork','factory-pass','factory-reject')},
    gates={n:r['status'] for n,r in qualification['cases'].items()},
    corrected_factory_gate=strict_json((root/'hosted-qualification-factory-corrected/qualification.json').read_bytes())['cases'],
    results=checked,stage2_pass=False,
    verification='independent offline rehash/readback of retained authenticated-client observations, not fresh server query')
(job/'independent-all-verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='results'},indent=2))
