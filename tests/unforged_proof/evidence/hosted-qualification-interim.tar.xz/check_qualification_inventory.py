import ast,json,pathlib,re,hashlib
w=pathlib.Path(__file__).resolve().parent;r=w/'repo';h=r/'tests/unforged_proof'
baseline=json.loads((h/'existing-test-inventory.json').read_bytes());missing=[]
for row in baseline['files']:
    text=(w/row['file']).read_text()
    names={n.name for n in ast.walk(ast.parse(text)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))} if row['file'].endswith('.py') else set(re.findall(r'\bfn\s+(\w+)\s*\(',text))
    missing.extend((row['file'],n) for n in row['tests'] if n not in names)
files={p.name:sum(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_') for n in ast.walk(ast.parse(p.read_text()))) for p in sorted(h.glob('test_*.py'))}
result=dict(baseline_files=len(baseline['files']),baseline_definitions=sum(x['count'] for x in baseline['files']),missing=missing,current_fast_files=files,current_fast_definitions=sum(files.values()))
(w/'qualification-inventory-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if missing:raise SystemExit(1)
