import pathlib,json,base64,hashlib,subprocess
p=pathlib.Path(__file__).resolve().parent
jobs=json.loads((p/'jobs.json').read_text());out=[]
for job in jobs:
 name=job['name'];r=json.loads((p/(name+'-run.json')).read_text());raw=base64.b64decode(r['response_base64']);head,body=raw.split(b'\r\n\r\n',1)
 assert head.startswith(b'HTTP/1.1 200 OK')
 assert ('X-Caos-Image: '+job['image']).encode() in head
 assert b'X-Caos-Cache: miss' in head
 assert body.decode().strip()=='blob '+job['expected_blob']
 o=json.loads((p/(name+'-result-object.json')).read_text());obj=base64.b64decode(o['response_base64']).split(b'\r\n\r\n',1)[1]
 assert hashlib.sha1(obj).hexdigest()==job['expected_blob']
 assert obj.split(b'\0',1)[1]==(job['proof']+'\n').encode()
 out.append(dict(job,cache='miss',elapsed_seconds=r['elapsed_seconds'],nonce_verified=True))
w=pathlib.Path('/home/ubuntu/.hermes/kanban/workspaces/t_01a21c4b5645783f')
pins={name:subprocess.check_output(['git','rev-parse','HEAD'],cwd=w/name,text=True).strip() for name in ['repo','unforged','caos']}
(p/'verification.json').write_text(json.dumps({'verified_jobs':out,'source_pins':pins},indent=2))
print(json.dumps({'verified_jobs':out,'source_pins':pins},indent=2))
