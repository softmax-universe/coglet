# Existing immutable image execution probe — PASS

Live authenticated execution on both existing Docker pins succeeded 2026-11-28 08:43:15–08:43:20 UTC. Same ephemeral Iroh endpoint and connection served both requests; endpoint identity checked before connect: e05401185f40e92e694c635fa75ba4a8cdef5bfcb0f7759f0713decfd6c3d6ce. Broker scope caos.prod.connect supplied ticket only in process environment; ticket not persisted.

## Results

| Image | ArgTree | Result blob | /run duration | Receipt |
|---|---|---|---|---|
| std/bash existing digest 842b81ee7ab08908ab2cd09ad01c3727a5333c832c2fd76a2974339fc4bf31ad | 365fdc0ab638b35803430492e52a91ac4c13f343 | 7cedbd49f6ee5935ff0c475412e32db803f3c780 | 0.730 s | HTTP 200, X-Caos-Cache: miss |
| std/go existing digest de985d089552ab9de870c54e6e3e9d028300b517bf7ee389fe1079808b4a4421 | 914e00568217db2388dccd503297f4e95bec03d4 | 1dd9d25a8bd64c16c3a0453e44d1e2cdaf7d13de | 3.339 s | HTTP 200, X-Caos-Cache: miss |

Each receipt included X-Caos-Image exactly matching its submitted localhost:5000/caos@sha256 digest reference. Result objects were independently fetched, git SHA-1 checked, and decoded bytes checked against a fresh unique nonce plus image label. Verification executable returned success for both; see verification.json. This is actual cache-miss execution evidence, not resolution-only evidence. It establishes existing generic image dispatch was usable for these simple compatible drivers at observation time; it does not prove the parent's final suite or native executable A/B semantics. No worker identity, actual OCI runtime pull-cache disposition, or hardware identity is exposed by these receipts. X-Caos-Cache is the run-result memo disposition. /status/<ArgTree> returned HTTP 200 null for both; this is not a failed run and does not override the successful receipts and materialized result blobs.

## Supported submission path inspected and exercised

CAOS compute.rs lines 373–488: POST /submit JSON with bundle, base.type=docker, base.value=<exact immutable Docker reference>, locators={}, and unique salt. A bundle tree contains args/worker1. POST /object/ stores native serialized git objects; every written object and formed ArgTree was read back. POST /submit forms but does not execute the request. GET /run?req=<ArgTree> then executes and supplies cache/image receipt headers (main.rs 779–802).

std/bash/worker fetches worker1 then invokes bash. std/go/worker fetches worker1 then invokes go run inside /gomod. Accordingly, bash driver uses printf and caos put; Go driver uses only os/os-exec standard library to write the nonce and invoke caos put. No network workload, model calls, ref modifications, new workers, registration, registry push, deployment, or paid capacity. CAS writes are limited to harmless proof inputs/results authorized by the task.

12-second client wall time bounds for storage/submission/status, 65 seconds per /run, global 170-second coroutine bound. Both /run requests issued concurrently, with no polling or retries. These are client bounds, not a claim of server-side execution cancellation: source runner.rs says claimed jobs have no execution timeout. Both jobs completed before bounds.

## Pins and artifacts

- Unforged f9c627bcc09346b2923583037a10ac9a2fa8ea12
- CAOS 604b6024166e5eb4ffa41e3555c2f5f0bd9d06b6
- Parent repo 919c51a784c4d10d9deb82a9400dc37f85950867
- Local pins are inspected source versions, not deployed server binary attestation.

probe.py is the actual executed client; verify.py validates exact raw receipts and result bytes. jobs.json preserves submitted identities, nonce.txt the salt, and bash-worker1/go-worker1 the full drivers. Each request has its own JSON with lossless base64 request/response, readable text including all headers, timestamp, endpoint identity, timeout and elapsed time. No transport exceptions occurred. Source trees and build targets were not modified.

Reproduce (creates new CAS proof objects):
`token-broker exec --scope caos.prod.connect --reason 'Authorized bounded harmless synthetic execution on both existing immutable images; no new runner or deployment' -- uv run --with iroh python image-execution-probe/probe.py`
`python3 image-execution-probe/verify.py`
