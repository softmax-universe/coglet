import os,asyncio,json,pathlib,datetime,inspect,hashlib,base64,time,uuid,iroh
ROOT=pathlib.Path(__file__).resolve().parent
secret=os.environ['CAOS_IROH_TICKET']
PIN='e05401185f40e92e694c635fa75ba4a8cdef5bfcb0f7759f0713decfd6c3d6ce'
def red(s): return s.replace(secret,'[REDACTED_TICKET]')
async def val(x): return await x if inspect.isawaitable(x) else x
async def main():
 ticket=iroh.EndpointTicket.from_string(secret.removeprefix('caos://').removeprefix('unforged://').split('.')[0]);addr=ticket.endpoint_addr()
 assert addr.id().to_bytes().hex()==PIN
 ep=await val(iroh.Endpoint.bind(iroh.EndpointOptions()));conn=await asyncio.wait_for(val(ep.connect(addr,b'DUMBPIPEV0')),15)
 async def query(label,path,body=b'',method='GET',timeout=12):
  req=f'{method} {path} HTTP/1.1\r\nHost: caos\r\nX-Caos-World: host\r\nContent-Length: {len(body)}\r\nConnection: close\r\n\r\n'.encode()+body
  row={'label':label,'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'endpoint_identity':PIN,'request_base64':base64.b64encode(req).decode(),'request_text':req.decode(errors='replace'),'timeout_seconds':timeout};start=time.monotonic()
  (ROOT/(label+'.json')).write_text(json.dumps(row,indent=2))
  resp=b''
  try:
   async def exchange():
    stream=await val(conn.open_bi());send=stream.send();recv=stream.recv();await val(send.write_all(b'hello'+req));await val(send.finish());return await val(recv.read_to_end(1048576))
   resp=await asyncio.wait_for(exchange(),timeout)
   row.update(raw_response=red(resp.decode(errors='replace')),response_base64=base64.b64encode(resp).decode())
  except Exception as e: row.update(error_type=type(e).__name__,error=red(str(e)))
  row['elapsed_seconds']=time.monotonic()-start;(ROOT/(label+'.json')).write_text(json.dumps(row,indent=2));print(json.dumps(row),flush=True)
  head,_,data=resp.partition(b'\r\n\r\n')
  if resp and not head.startswith(b'HTTP/1.1 200'): raise RuntimeError(label+' failed: '+red(resp.decode(errors='replace')))
  return data
 async def put(label,kind,content):
  raw=f'{kind} {len(content)}\0'.encode()+content;oid=hashlib.sha1(raw).hexdigest();got=(await query(label,'/object/',raw,'POST')).decode().strip();assert got==oid,(got,oid)
  await query(label+'-readback','/object/'+oid)
  return oid
 nonce='image-exec-'+uuid.uuid4().hex
 (ROOT/'nonce.txt').write_text(nonce)
 refs={'bash':'localhost:5000/caos@sha256:842b81ee7ab08908ab2cd09ad01c3727a5333c832c2fd76a2974339fc4bf31ad','go':'localhost:5000/caos@sha256:de985d089552ab9de870c54e6e3e9d028300b517bf7ee389fe1079808b4a4421'}
 jobs=[]
 for name,ref in refs.items():
  proof=nonce+'-'+name
  if name=='bash': src=f"set -eu\nprintf '%s\\n' '{proof}' > /tmp/image-exec-proof\ncaos put /tmp/image-exec-proof /cas/out\n"
  else: src='package main\nimport("os";"os/exec")\nfunc main(){if e:=os.WriteFile("/tmp/image-exec-proof",[]byte("'+proof+'\\n"),0600);e!=nil{panic(e)};c:=exec.Command("caos","put","/tmp/image-exec-proof","/cas/out");c.Stdout=os.Stdout;c.Stderr=os.Stderr;if e:=c.Run();e!=nil{panic(e)}}\n'
  (ROOT/(name+'-worker1')).write_text(src)
  worker=await put(name+'-worker','blob',src.encode())
  args=await put(name+'-args','tree',b'100644 worker1\0'+bytes.fromhex(worker))
  bundle=await put(name+'-bundle','tree',b'40000 args\0'+bytes.fromhex(args))
  body=json.dumps({'bundle':bundle,'base':{'type':'docker','value':ref},'locators':{},'salt':nonce}).encode()
  submitted=(await query(name+'-submit','/submit',body,'POST')).decode();req=submitted.splitlines()[0].split()[1]
  await query(name+'-request-readback','/object/'+req)
  jobs.append({'name':name,'image':ref,'arg_tree':req,'proof':proof,'expected_blob':hashlib.sha1(('blob '+str(len(proof)+1)+'\0'+proof+'\n').encode()).hexdigest()})
 (ROOT/'jobs.json').write_text(json.dumps(jobs,indent=2))
 async def run(job):
  name=job['name'];req=job['arg_tree']
  data=await query(name+'-run','/run?req='+req,timeout=65)
  await query(name+'-status','/status/'+req)
  if data:
   fields=data.decode().strip().split()
   if len(fields)==2: await query(name+'-result-object','/object/'+fields[1])
 await asyncio.gather(*(run(j) for j in jobs))
 await val(ep.close())
try: asyncio.run(asyncio.wait_for(main(),170))
except Exception as e:
 row={'fatal_error_type':type(e).__name__,'fatal_error':red(str(e))};(ROOT/'fatal.json').write_text(json.dumps(row));print(json.dumps(row),flush=True)
