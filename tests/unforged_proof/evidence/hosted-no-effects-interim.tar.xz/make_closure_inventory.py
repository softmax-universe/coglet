import ast,hashlib,json,pathlib,subprocess,sys,tomllib
ROOT=pathlib.Path(__file__).resolve().parent/'repo'
sys.path.insert(0,str(ROOT/'tests/unforged_proof'))
import no_effects_policy
files=no_effects_policy.selected_sources()
# This is a CANDIDATE pin list for review, NOT approval by generation.
(ROOT/'tests/unforged_proof/no-effects-source-pins.json').write_text(json.dumps(dict(version=1,files={p:hashlib.sha256(b).hexdigest() for p,b in files.items()}),indent=2)+'\n')
base='555ae294ef5a56ab5903277b1e3da513148fee59'
changes={}
for p in ('tests/unforged_proof/driver/Cargo.lock','tools/visualizer/native/Cargo.lock'):
 old=tomllib.loads(subprocess.check_output(['git','show',base+':'+p],cwd=ROOT).decode())
 new=tomllib.loads((ROOT/p).read_text())
 o={(v['name'],v['version']):v.get('checksum') for v in old['package']};n={(v['name'],v['version']):v.get('checksum') for v in new['package']}
 changes[p]=dict(removed=sorted(set(o)-set(n)),added=sorted(set(n)-set(o)),checksum_changed=[k for k in o.keys()&n.keys() if o[k]!=n[k]])
inv={str(p.relative_to(ROOT)):sum(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_') for n in ast.walk(ast.parse(p.read_text()))) for p in sorted((ROOT/'tests/unforged_proof').glob('test_*.py'))}
pathlib.Path('closure-inventory.json').write_text(json.dumps(dict(tests=inv,files=len(inv),definitions=sum(inv.values()),lock_changes=changes,source_pin_files=len(files)),indent=2)+'\n')
print(json.dumps(dict(files=len(inv),definitions=sum(inv.values()),source_pin_files=len(files),lock_added={p:v['added'] for p,v in changes.items()},checksum_changed={p:v['checksum_changed'] for p,v in changes.items()}),indent=2))
