from pathlib import Path
import json,sys
w=Path(__file__).resolve().parent
sys.path.insert(0,str(w/'repo/crates/coglet-gate/python'))
sys.path.insert(0,str(w/'repo/tests/unforged_proof'))
from verify_loopback_probe import verify
from guarded_transport import strict_json
p=w/'hosted-no-effects-cut';c=strict_json((p/'config.json').read_bytes())
rows=[]
for name,trace in [('model',p/'model.json'),('replay',p/'oracles/replay-trace.json')]:
 oracle=strict_json(trace.read_bytes())
 for step in range(len(oracle['records'])):
  rows.append(verify(p/f'{name}-{step}',trace,step,image=c['image'],source=c['source'],driver_hash=c['driver_sha256'],bridge_hash=c['bridge_sha256']))
assert len(rows)==11 and len({r['request'] for r in rows})==11
result=dict(count=len(rows),unique_requests=len({r['request'] for r in rows}),config=c,steps=rows)
(p/'offline-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(count=len(rows),requests=[r['request'] for r in rows]),indent=2))
