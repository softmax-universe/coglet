from pathlib import Path
import os,subprocess,json
w=Path(__file__).resolve().parent;r=w/'repo';out=w/'stage1-closure-regression';bins=w/'stage1-closure-bin';bins.mkdir(exist_ok=False)
static=r/'target/static-proof/x86_64-unknown-linux-gnu/debug'
for name,path in {'coglet-unforged-proof':static/'coglet-unforged-proof','cogletd':static/'cogletd',
'coglet':r/'target/debug/coglet','coglet-unforged-prepare':r/'target/debug/coglet-unforged-prepare'}.items():
 (bins/name).symlink_to(path)
command=['python3',str(r/'tests/unforged_proof/run.py'),'--unforge',str(w/'unforged/target/debug/unforge'),'--bin-dir',str(bins),'--output',str(out)]
env=dict(os.environ,PATH=str(w/'git-tools/bin')+os.pathsep+os.environ['PATH'])
result=subprocess.run(command,env=env,capture_output=True,timeout=240)
(w/'stage1-closure.stdout').write_bytes(result.stdout);(w/'stage1-closure.stderr').write_bytes(result.stderr)
(w/'stage1-closure-command.json').write_text(json.dumps(dict(command=command,returncode=result.returncode),indent=2)+'\n')
# Compare exact preparation bytes to retained old driver on same actual CLI-built package.
if (out/'package').exists():
 old=subprocess.run([str(w/'original-precut-driver'),'prepare',str(out/'package'),str(w/'old-prepare-job.json')],capture_output=True)
 new=subprocess.run([str(bins/'coglet-unforged-prepare'),str(out/'package'),str(w/'new-prepare-job.json')],capture_output=True)
 equal=old.returncode==new.returncode==0 and (w/'old-prepare-job.json').read_bytes()==(w/'new-prepare-job.json').read_bytes()
 (w/'prepare-equivalence.json').write_text(json.dumps(dict(old_exit=old.returncode,new_exit=new.returncode,exact_bytes_equal=equal))+'\n')
 print('helper exact bytes equal:',equal)
print('stage1 exit',result.returncode);print(result.stdout.decode()[-2000:]);print(result.stderr.decode()[-3000:])
