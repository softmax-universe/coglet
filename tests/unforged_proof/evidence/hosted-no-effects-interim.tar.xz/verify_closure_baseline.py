from pathlib import Path
import ast,json,re,sys
w=Path(__file__).resolve().parent
inv=json.loads((w/'repo/tests/unforged_proof/existing-test-inventory.json').read_bytes())
rows=[];missing=[]
for item in inv['files']:
 p=w/item['file'];text=p.read_text()
 if p.suffix=='.py':names={n.name for n in ast.walk(ast.parse(text)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
 else:names=set(re.findall(r'\bfn\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(',text))
 lost=set(item['tests'])-names
 if lost:missing.append(dict(file=item['file'],missing=sorted(lost)))
 rows.append(dict(file=item['file'],baseline_count=item['count'],retained=not lost))
result=dict(baseline_files=len(rows),baseline_definitions=sum(i['count'] for i in inv['files']),missing=missing,files=rows)
(w/'closure-baseline-retained.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
if missing:sys.exit(1)
