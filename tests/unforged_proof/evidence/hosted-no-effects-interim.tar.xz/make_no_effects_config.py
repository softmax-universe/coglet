from pathlib import Path
import hashlib,json,subprocess
w=Path(__file__).resolve().parent;r=w/'repo'
config={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip(),
'endpoint':'e05401185f40e92e694c635fa75ba4a8cdef5bfcb0f7759f0713decfd6c3d6ce',
'image':'native@sha256:2e92d104eed5ad02c0daa765c4b17aa35f6be942e39248ef53fdd4987b429ff5'}
for name,path in {'driver':r/'target/static-proof/x86_64-unknown-linux-gnu/debug/coglet-unforged-proof',
'bridge':w/'unforged/target/debug/coglet-hosted-bridge','daemon':r/'target/static-proof/x86_64-unknown-linux-gnu/debug/cogletd','proof':r/'target/static-proof/x86_64-unknown-linux-gnu/debug/coglet-sandbox-proof'}.items():
 config[name]=str(path);config[name+'_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
with (w/'no-effects-config.json').open('x') as out:json.dump(config,out,indent=2);out.write('\n')
print(json.dumps(config,indent=2))
