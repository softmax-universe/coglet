# Authenticated image capability probe (2026-11-28 08:34–08:37 UTC)

## Outcome
Two distinct existing std image identities resolved successfully through live supported /eval and /resolve-image contracts. Docker digest-pinned references were each independently accepted by /resolve-image (HTTP 200). This establishes live resolution support, NOT execution capacity or A/B acceptance. No /run, /submit, /runner/poll, deployment, worker start, registry-push command, or model call was issued. /eval and tree /resolve-image can internally memoize; the source contract allows conversion on a cache miss, so this report does not assert the server performed no internal conversion.

Endpoint authenticated from broker ticket and checked before connect: e05401185f40e92e694c635fa75ba4a8cdef5bfcb0f7759f0713decfd6c3d6ce.
Broker scope caos.prod.connect, auto. Ticket never printed or saved; UNFORGED_CAOS_URL set only inside process. Wire uses Iroh DUMBPIPEV0, hello opener, HTTP; ephemeral local endpoint only (no runner registration).

## Exact existing identities/provenance
Pinned public locator commit from Unforged DEFAULT_CAOS_STD_BASH_LOCATOR: 7f0efc5b73ce61bf66dff37bb209901a83bc8dec, repository https://github.com/softmax-universe/caos.

- dir=std/bash: GET /eval?root:@@=<percent-encoded locator> -> HTTP 200 `tree 8f0085cd8fd63997ef172eb80913e601e323beba`.
  GET /resolve-image?image=8f0085cd8fd63997ef172eb80913e601e323beba -> HTTP 200 `localhost:5000/caos@sha256:842b81ee7ab08908ab2cd09ad01c3727a5333c832c2fd76a2974339fc4bf31ad`.
- dir=std/go, same repo/commit: /eval -> HTTP 200 `tree ff84cdec7ecbc09fb39dd430c5d42daa36a56441`.
  /resolve-image?image=ff84cdec7ecbc09fb39dd430c5d42daa36a56441 -> HTTP 200 `localhost:5000/caos@sha256:de985d089552ab9de870c54e6e3e9d028300b517bf7ee389fe1079808b4a4421`.
- Each returned ref was then submitted to /resolve-image with docker:// prefix; both HTTP 200 returned exactly the same immutable ref. Raw requests/headers/bodies are host-docker-pinned-{bash,go}.json.

Use CaosBaseSpec::Docker with returned name@sha256 ref, not the original mutable or git locator, for parent same-client image A/B implementation. These images differ in interpreter contents; this does not establish compatibility with a particular Coglet synthetic driver. No actual image execution was attempted, so availability of an existing generic runner remains unproven by this probe.

## Native route
Live /resolve-image for the exact UNFORGED_CAOS_IMAGE_REF sentinel returned HTTP 503:
`no native worker with a known executable digest; refusing sentinel fallback`.
Existing bridge same-client discovery returned [null,null]. This is BASE-ONLY discovery: source explicitly says required-pool/required-engine advertisements do not match it. It therefore does NOT prove there is no pool-scoped native worker or no second executable. There is no source-supported read-only advertisement inventory endpoint found; do not manufacture a digest, sentinel rewrite, or fake advertisement. Original supplied native digest remains native@sha256:2e92d104eed5ad02c0daa765c4b17aa35f6be942e39248ef53fdd4987b429ff5, not independently rediscovered here.

## Source pins/contracts
- Unforged f9c627bcc09346b2923583037a10ac9a2fa8ea12, src/caos.rs lines 43–47 default locator; 1433–1459 base-only native discovery; 1824–1858 public raw request APIs; src/iroh_net.rs DUMBPIPEV0 and hello.
- CAOS read-only source 604b6024166e5eb4ffa41e3555c2f5f0bd9d06b6: rust/crates/server/src/compute.rs 106–129 resolve-image; 132–214 eval typed-root contract. runner.rs 75–106 native selection/poll_identity only accepts native@sha256, not Docker identity advertisement. README 412–452 native semantics and 454–470 Git image conversion. main.rs generic runnerd is an ordinary poller with no required args and image_ref is supplied per dispatch. Server /version returns `unknown`; source checkout is not deployed source attestation.

## Commands/artifacts
From workspace:
`token-broker exec --scope caos.prod.connect --reason 'Read-only existing image capability discovery; no execution or new worker' -- python3 image-capability-probe/probe.py`
`token-broker exec --scope caos.prod.connect --reason 'Read-only validate discovered immutable Docker references; no execution' -- uv run --with iroh python image-capability-probe/wire_probe.py`
Wire dependency: PyPI iroh installed by uv for this probe. Current script reproduces final digest validation; earlier exact request strings and responses remain in JSON. All request bodies absent. Requests use X-Caos-World: host, matching pinned Unforged transport convention and server response.

Retained initial failed public-world calls (400 world mismatch) and encoded-key /eval calls (400 missing typed root). Corrected calls preserve literal root:@@ key and percent-encode its value. These initial client-format errors are NOT service capability refusals.

## Remaining scope
Parent can now implement bounded same-client A/B controls using these two resolved Docker pins, subject to harmless driver compatibility. This report is not PASS for execution or upgrade. If generic runner execution cannot serve them, no authorized alternate capacity was started: temporary second native worker, worker upgrade, paid capacity, new pushes or deployment remain excluded and need separate explicit scope.
