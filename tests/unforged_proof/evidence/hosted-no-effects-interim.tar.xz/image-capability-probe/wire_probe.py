import os,asyncio,json,pathlib,urllib.parse,datetime,inspect,iroh
ROOT=pathlib.Path(__file__).resolve().parent
secret=os.environ['CAOS_IROH_TICKET'];os.environ['UNFORGED_CAOS_URL']=secret
PIN='e05401185f40e92e694c635fa75ba4a8cdef5bfcb0f7759f0713decfd6c3d6ce'
def red(s):return s.replace(secret,'[REDACTED_TICKET]')
async def val(x):return await x if inspect.isawaitable(x) else x
async def main():
 raw=secret.removeprefix('caos://').removeprefix('unforged://').split('.')[0]
 ticket=iroh.EndpointTicket.from_string(raw);addr=ticket.endpoint_addr()
 assert addr.id().to_bytes().hex()==PIN,'endpoint pin mismatch'
 ep=await val(iroh.Endpoint.bind(iroh.EndpointOptions()))
 conn=await asyncio.wait_for(val(ep.connect(addr,b'DUMBPIPEV0')),15)
 async def query(label,path):
  req=f'GET {path} HTTP/1.1\r\nHost: caos\r\nX-Caos-World: host\r\nConnection: close\r\n\r\n'
  row={'label':label,'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':req,'endpoint_identity':PIN}
  try:
   async def exchange():
    stream=await val(conn.open_bi());send=stream.send();recv=stream.recv()
    await val(send.write_all(b'hello'+req.encode()));await val(send.finish())
    return await val(recv.read_to_end(1048576))
   resp=await asyncio.wait_for(exchange(),15);row['raw_response']=red(resp.decode(errors='replace'))
  except Exception as e:row['error']=red(str(e))
  (ROOT/('host-'+label+'.json')).write_text(json.dumps(row,indent=2));print(json.dumps(row),flush=True)
  return row
 await query('docker-pinned-bash','/resolve-image?image='+urllib.parse.quote('docker://localhost:5000/caos@sha256:842b81ee7ab08908ab2cd09ad01c3727a5333c832c2fd76a2974339fc4bf31ad',safe=''))
 await query('docker-pinned-go','/resolve-image?image='+urllib.parse.quote('docker://localhost:5000/caos@sha256:de985d089552ab9de870c54e6e3e9d028300b517bf7ee389fe1079808b4a4421',safe=''))
 await val(ep.close())
try:asyncio.run(main())
except Exception as e:
 row={'fatal_error':red(str(e))};(ROOT/'wire-fatal.json').write_text(json.dumps(row));print(json.dumps(row))
