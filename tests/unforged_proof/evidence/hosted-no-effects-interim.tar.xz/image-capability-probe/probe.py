"""Read-only authenticated native discovery; never persist credential."""
import os, subprocess, json, pathlib, datetime
ROOT=pathlib.Path(__file__).resolve().parent
secret=os.environ['CAOS_IROH_TICKET']
env=os.environ.copy();env['UNFORGED_CAOS_URL']=secret
cmd=[str(ROOT.parent/'unforged/target/debug/coglet-hosted-bridge')]
r=subprocess.run(cmd,env=env,capture_output=True,timeout=40)
def redact(b):
    return b.decode(errors='replace').replace(secret,'[REDACTED_TICKET]')
record={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'scope':'caos.prod.connect','stdout':redact(r.stdout),'stderr':redact(r.stderr),'exit_code':r.returncode}
(ROOT/'native-discovery.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
