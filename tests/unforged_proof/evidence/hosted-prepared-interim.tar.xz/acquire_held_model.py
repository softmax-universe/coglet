import hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
repo=root/'repo'
driver=repo/'target/static-proof/x86_64-unknown-linux-gnu/debug/coglet-unforged-proof'
trace=subprocess.run([str(driver),'record-model',str(repo)],capture_output=True,check=True).stdout
value=json.loads(trace)
(root/'held-model-trace.json').write_bytes(trace)
(root/'held-model-snapshot.json').write_text(json.dumps(value['initial_files']))
print(json.dumps(dict(coglet=value['coglet'],step0=value['records'][0]['output_hash'],driver_sha256=hashlib.sha256(driver.read_bytes()).hexdigest(),bridge_sha256=hashlib.sha256((root/'unforged/target/debug/coglet-hosted-bridge').read_bytes()).hexdigest())))
