"""Offline readback verifier for the retained prepared-model increment."""
import json,sys,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'repo/tests/unforged_proof'))
sys.path.insert(0,str(root/'repo/crates/coglet-gate/python'))
from guarded_transport import strict_json
from wire_trees import verify_output
from diagnostic_receipts import verify_isolation_sidecar
from standard_step import require_fresh
child=root/'prepared-model-reviewed'
rows=[strict_json(line) for line in (child/'bridge.jsonl').read_bytes().splitlines()]
def one(phase):
    selected=[r for r in rows if r.get('phase')==phase]
    if len(selected)!=1: raise ValueError('ambiguous '+phase)
    return selected[0]
submitted,executed,sidecar=one('submitted'),one('executed'),one('sidecar-readback')
request=submitted['request']
image='native@sha256:2e92d104eed5ad02c0daa765c4b17aa35f6be942e39248ef53fdd4987b429ff5'
require_fresh(executed,request=request,image=image)
status=[r for r in rows if r.get('phase')=='readback' and r['path']==f'/status/{request}?all=1']
if len(status)!=1 or status[0]['http_status']!=200: raise ValueError('status absent')
body=strict_json(status[0]['body'])
if body['arg_tree']!=request or body['out_trace']!=[sidecar['oid']]: raise ValueError('sidecar binding')
observation=verify_isolation_sidecar(sidecar['raw_payload'].encode(),sidecar['oid'],request=request,salt=submitted['salt'])
actual=verify_output(rows,executed['result_oid'])
trace=strict_json((root/'held-model-trace.json').read_bytes())
command=strict_json((child/'command.json').read_bytes())
if command['trace_sha256']!=hashlib.sha256((root/'held-model-trace.json').read_bytes()).hexdigest(): raise ValueError('trace differs')
if actual!=trace['records'][0]['output_hash']: raise ValueError('whole tree differs')
result=dict(count=1,request=request,output_hash=actual,sidecar=sidecar['oid'],source=command['source_head'],observations=observation,qualification='readback verified prepared synthetic model0 only; NOT stage2 PASS')
(child/'independent-verification.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
